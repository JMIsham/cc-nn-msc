import sys
import os
sys.path.append("./")
from utils import org_name_to_id, logical_time, get_timestamp
import json
from datetime import datetime

timestamp = None

def set_bol_timestamp(new_timestamp):
    global timestamp
    timestamp = new_timestamp

def new_bol(line):
    bol = {
    "action" : "SET_BOL",
    "purchase_order_number": line[5],
    "bol" : {
        "purchase_order_number": line[5],
        "bol_id":line[1],
        "buyer": org_name_to_id[line[2]],
        "supplier": org_name_to_id[line[3]],
        "freight_forwarder":org_name_to_id[line[4]],
        "timestamp":timestamp,
        "products": [],
        "trailer":{
          "id":line[9],
          "loaded_by":"supplier",
          "counted_by":"carrier"
            },
        "seals":[
          {
             "seal_number":line[12],
             "seal_status":line[13]
          }
        ],
        "date_order_shipped": datetime.strptime(line[14], "%m/%d/%Y").strftime('%Y-%m-%d'),
        "date_order_delivered": datetime.strptime(line[15], "%m/%d/%Y").strftime('%Y-%m-%d'),
        "address_ship_from": {
            "street_address": line[16],
            "address_line_2": line[17],
            "city": line[18],
            "state": line[19],
            "zip_code": line[20]
        },
        "address_ship_to": {
            "street_address": line[21],
            "address_line_2": line[22],
            "city": line[23],
            "state": line[14],
            "zip_code": line[25]
        },
        "freight_terms":line[26],
        "carrier_name":line[27],
        "supplier_signature":line[28],
        "carrier_signature":line[29],
        "carrier_standard_carrier_alpha_code":"ABCD"
        },
    "timestamp": timestamp
    }
    return bol

def with_bol_product(bol, line):
    product = {
           "product":line[6],
           "purchase_order_number":line[5],
           "quantity":int(line[7]),
           "quantity_unit_of_measure":line[8],
           "timestamp": timestamp
        }
    products = bol["bol"]["products"]
    products.append(product)
    bol["bol"]["products"] = products
    return bol

def accept_bol(bol, line):
    set_bol_timestamp(get_timestamp())
    accept_bol = {
    "action" : "ACCEPT_BOL",
    "purchase_order_number": line[5],
    "timestamp": timestamp
    }
    return accept_bol

def verify_bol(bol, line):
    set_bol_timestamp(get_timestamp())
    verify_bol = {
    "action" : "VERIFY_BOL",
    "purchase_order_number": line[5],
    "timestamp": timestamp
    }
    return verify_bol

def load_bol(bol, line):
    set_bol_timestamp(get_timestamp())
    load_bol = {
    "action" : "LOAD_TRUCK",
    "purchase_order_number": line[5],
    "timestamp": timestamp
    }
    return load_bol

def ship_bol(bol, line):
    set_bol_timestamp(get_timestamp())
    ship_bol = {
    "action" : "SHIP",
    "purchase_order_number": line[5],
    "timestamp": timestamp
    }
    return ship_bol

def arrive_bol(bol, line):
    set_bol_timestamp(get_timestamp())
    arrive_bol = {
    "action" : "ARRIVE",
    "purchase_order_number": line[5],
    "timestamp": timestamp
    }
    return arrive_bol

def event(bol, line):
    set_bol_timestamp(get_timestamp())
    event = {
        "action" : "SET_CTE",
        "purchase_order_number": line[5],
        "critical_event" : {
            "event" : "SEAL_BREAK",
            "timestamp": timestamp
        },
        "timestamp": timestamp
        }
    return event

def save_bol(bol, line):
    scenario = line[0].replace(" ", "_")
    verify_bol_json = verify_bol(bol, line)
    accept_bol_json = accept_bol(bol, line)
    load_bol_json = load_bol(bol, line)
    ship_bol_json = ship_bol(bol, line)
    event_json = event(bol, line)
    arrive_bol_json = arrive_bol(bol, line)

    with open('output/' + scenario + "/order" + '/set_bol.json', 'w') as f:
        json.dump(bol, f, indent=2)
    
    three_party_bol = bol
    three_party_bol['action'] = 'PROPOSE_BOL'
    with open('output/' + scenario + "/shipment" + '/submit_bol.json', 'w') as f:
        json.dump(three_party_bol, f, indent=2)
    
    with open('output/' + scenario + "/shipment" + '/verify_bol.json', 'w') as f:
        json.dump(verify_bol_json, f, indent=2)
    
    with open('output/' + scenario + "/shipment" + '/accept_bol.json', 'w') as f:
        json.dump(accept_bol_json, f, indent=2)
    
    with open('output/' + scenario + "/shipment" + '/load_bol.json', 'w') as f:
        json.dump(load_bol_json, f, indent=2)
    
    with open('output/' + scenario + "/shipment" + '/ship_bol.json', 'w') as f:
        json.dump(ship_bol_json, f, indent=2)
    
    with open('output/' + scenario + "/shipment" + '/arrive_bol.json', 'w') as f:
        json.dump(arrive_bol_json, f, indent=2)
    
    if bol['bol']['seals'][0]['seal_status'] == "Broken" :
        with open('output/' + scenario + "/order" + '/event.json', 'w') as f:
            json.dump(event_json, f, indent=2)
        
        event_json['action'] = 'ADD_CTE'
        with open('output/' + scenario + "/shipment" + '/event.json', 'w') as f:
            json.dump(event_json, f, indent=2)



    

