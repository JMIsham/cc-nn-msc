#!/bin/sh

# Bring down the setup
./bootstrap -s -d
sleep 5
# Generate a new set of artefacts
./generate -s -o "tys jbh cgl"
# tys fdx tys"

# Bring up the components
./bootstrap -s -u
# Wait for a while before doing next task
sleep 5

# Go and create circuits
./scripts/debug/circuit -p -a -o "tys jbh cgl" -n TJC -s
./scripts/debug/circuit -p -a -o "tys cgl" -n TC -s
# Wait for a while for circuits to accept
sleep 5

# Deploy the contracts
./scripts/debug/deploy -c TJC -p contract-scar/pike_1.0.0.scar -p contract-scar/shipment-contract_1.0.0.scar -d -o "tys" -s
./scripts/debug/deploy -c TC -p contract-scar/pike_1.0.0.scar -p contract-scar/order-contract_1.0.0.scar -d -o "tys" -s
./scripts/debug/deploy -c TC -p contract-scar/pike_1.0.0.scar -p contract-scar/order-contract_1.0.0.scar -d -o "tys" -s
sleep 5

# Submit pike payloads
./scripts/debug/client -C pike -V 1.0.0 -c TC -o tys -p buy -s
./scripts/debug/client -C pike -V 1.0.0 -c TC -o cgl -p sel -s

./scripts/debug/client -C pike -V 1.0.0 -c TJC -o tys -p buy -s
./scripts/debug/client -C pike -V 1.0.0 -c TJC -o cgl -p sel -s
./scripts/debug/client -C pike -V 1.0.0 -c TJC -o jbh -p car -s
sleep 5

# Cambio components
./scripts/debug/component -c sde -s
./scripts/debug/component -c db-api -s
./scripts/debug/component -c sapling-dev-server -s
./scripts/debug/component -c cambio-ui -s
