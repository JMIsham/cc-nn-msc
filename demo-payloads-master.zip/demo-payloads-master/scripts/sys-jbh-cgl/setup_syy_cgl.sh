#!/bin/sh

# Bring down the setup
./bootstrap -s -d
sleep 5
# Generate a new set of artefacts
./generate -s -o "syy jbh cgl"
# syy fdx tys"

# Bring up the components
./bootstrap -s -u
# Wait for a while before doing next task
sleep 5

# Go and create circuits
./scripts/debug/circuit -p -a -o "syy jbh cgl" -n SJC -s
./scripts/debug/circuit -p -a -o "syy cgl" -n SC -s
# Wait for a while for circuits to accept
sleep 5

# Deploy the contracts
./scripts/debug/deploy -c SJC -p contract-scar/pike_1.0.0.scar -p contract-scar/shipment-contract_1.0.0.scar -d -o "syy" -s
./scripts/debug/deploy -c SC -p contract-scar/pike_1.0.0.scar -p contract-scar/order-contract_1.0.0.scar -d -o "syy" -s
./scripts/debug/deploy -c SC -p contract-scar/pike_1.0.0.scar -p contract-scar/order-contract_1.0.0.scar -d -o "syy" -s
sleep 5

# Submit pike payloads
./scripts/debug/client -C pike -V 1.0.0 -c SC -o syy -p buy -s
./scripts/debug/client -C pike -V 1.0.0 -c SC -o cgl -p sel -s

./scripts/debug/client -C pike -V 1.0.0 -c SJC -o syy -p buy -s
./scripts/debug/client -C pike -V 1.0.0 -c SJC -o cgl -p sel -s
./scripts/debug/client -C pike -V 1.0.0 -c SJC -o jbh -p car -s
sleep 5

# Cambio components
./scripts/debug/component -c sde -s
./scripts/debug/component -c db-api -s
./scripts/debug/component -c sapling-dev-server -s
./scripts/debug/component -c cambio-ui -s
