#!/bin/bash

# A sample transaction
function pause(){
 read -s -n 1 -p "Press any key to continue . . .\n \n"
 echo ""
}
 
## Pause it ##


./scripts/debug/client -C "order-contract" -V 1.0.0 -c SC -i output/$1/order/po.json -o syy
./scripts/debug/client -C "order-contract" -V 1.0.0 -c SC -i output/$1/order/invoice.json -o cgl
./scripts/debug/client -C "order-contract" -V 1.0.0 -c SC -i output/$1/order/po_accept.json -o cgl
pause

./scripts/debug/client -C "shipment-contract" -V 1.0.0 -c SJC -i output/$1/shipment/submit_bol.json -o cgl
./scripts/debug/client -C "order-contract" -V 1.0.0 -c SC -i output/$1/order/set_bol.json -o cgl
pause

./scripts/debug/client -C "order-contract" -V 1.0.0 -c SC -i output/$1/order/update_invoice_bol.json -o cgl
./scripts/debug/client -C "shipment-contract" -V 1.0.0 -c SJC -i output/$1/shipment/verify_bol.json -o cgl
pause

./scripts/debug/client -C "shipment-contract" -V 1.0.0 -c SJC -i output/$1/shipment/accept_bol.json -o jbh
./scripts/debug/client -C "shipment-contract" -V 1.0.0 -c SJC -i output/$1/shipment/load_bol.json -o jbh
./scripts/debug/client -C "shipment-contract" -V 1.0.0 -c SJC -i output/$1/shipment/ship_bol.json -o jbh
pause


./scripts/debug/client -C "order-contract" -V 1.0.0 -c SC -i output/$1/order/event.json -o syy
./scripts/debug/client -C "shipment-contract" -V 1.0.0 -c SJC -i output/$1/shipment/event.json -o jbh
pause


./scripts/debug/client -C "shipment-contract" -V 1.0.0 -c SJC -i output/$1/shipment/arrive_bol.json -o jbh
./scripts/debug/client -C "shipment-contract" -V 1.0.0 -c SJC -i output/$1/shipment/submit_receipt.json -o syy
./scripts/debug/client -C "order-contract" -V 1.0.0 -c SC -i output/$1/order/set_receipt.json -o syy
pause

./scripts/debug/client -C "order-contract" -V 1.0.0 -c SC -i output/$1/order/update_invoice_receipt.json -o cgl
./scripts/debug/client -C "shipment-contract" -V 1.0.0 -c SJC -i output/$1/shipment/resolve_bol_gr.json -o cgl
pause

./scripts/debug/client -C "order-contract" -V 1.0.0 -c SC -i output/$1/order/payment_1.json -o syy
pause

./scripts/debug/client -C "order-contract" -V 1.0.0 -c SC -i output/$1/order/payment_2.json -o syy
