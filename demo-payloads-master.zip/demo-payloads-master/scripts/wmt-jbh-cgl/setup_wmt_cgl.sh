#!/bin/sh

# Bring down the setup
./bootstrap -s -d
sleep 5
# Generate a new set of artefacts
./generate -s -o "wmt jbh cgl"
# wmt fdx tys"

# Bring up the components
./bootstrap -s -u
# Wait for a while before doing next task
sleep 5

# Go and create circuits
./scripts/debug/circuit -p -a -o "wmt jbh cgl" -n WJC -s
./scripts/debug/circuit -p -a -o "wmt cgl" -n WC -s
# Wait for a while for circuits to accept
sleep 5

# Deploy the contracts
./scripts/debug/deploy -c WJC -p contract-scar/pike_1.0.0.scar -p contract-scar/shipment-contract_1.0.0.scar -d -o "wmt" -s
./scripts/debug/deploy -c WC -p contract-scar/pike_1.0.0.scar -p contract-scar/order-contract_1.0.0.scar -d -o "wmt" -s
./scripts/debug/deploy -c WC -p contract-scar/pike_1.0.0.scar -p contract-scar/order-contract_1.0.0.scar -d -o "wmt" -s
sleep 5

# Submit pike payloads
./scripts/debug/client -C pike -V 1.0.0 -c WC -o wmt -p buy -s
./scripts/debug/client -C pike -V 1.0.0 -c WC -o cgl -p sel -s

./scripts/debug/client -C pike -V 1.0.0 -c WJC -o wmt -p buy -s
./scripts/debug/client -C pike -V 1.0.0 -c WJC -o cgl -p sel -s
./scripts/debug/client -C pike -V 1.0.0 -c WJC -o jbh -p car -s
sleep 5

# Cambio components
./scripts/debug/component -c sde -s
./scripts/debug/component -c db-api -s
./scripts/debug/component -c sapling-dev-server -s
./scripts/debug/component -c cambio-ui -s
