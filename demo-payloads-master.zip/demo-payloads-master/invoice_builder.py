import sys
import os
sys.path.append("./")
from utils import org_name_to_id
import json

timestamp = None

def set_invoice_timestamp(new_timestamp):
    global timestamp
    timestamp = new_timestamp

def new_invoice(line):
    invoice = {
    "action":"SUBMIT_INVOICE",
    "purchase_order_number":line[3],
    "invoice":{
        "invoice_number":line[2],
        "purchase_order_number":line[3],
        "timestamp":timestamp,
        "buyer":line[4],
        "supplier":line[5],
        "products":[]
    },
    "timestamp":timestamp
    }

    return invoice

def with_invoice_product(invoice, line):
    product = {
           "product":line[6],
           "purchase_order_number":line[3],
           "quantity":int(line[7]),
           "quantity_unit_of_measure":line[8],
           "product_price":float((line[9].strip())[1:]),
           "timestamp": timestamp
        }
    invoice["invoice"]["products"].append(product)
    return invoice


def save_invoice(invoice, line):
    scenario = line[1].replace(" ", "_")

    with open('output/' + scenario + "/order" + '/invoice.json', 'w') as f:
        json.dump(invoice, f, indent=2)


