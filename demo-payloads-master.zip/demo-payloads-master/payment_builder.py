import sys
import os
sys.path.append("./")
from utils import org_name_to_id
import json

timestamp = None

def set_payment_timestamp(new_timestamp):
    global timestamp
    timestamp = new_timestamp

def new_payment(line):
    payment = {
    "action":"SUBMIT_PAYMENT",
    "purchase_order_number":line[1],
    "payment":{
        "payment_id":line[3],
        "payment_amount":float((line[4].replace(',', '').strip())[1:]),
        "timestamp":timestamp
    },
    "timestamp":timestamp
    }

    return payment

def save_payment(line, payment_number):
    scenario = line[0].replace(" ", "_")
    payment = new_payment(line)
    with open('output/' + scenario + "/order" + '/payment_' + str(payment_number) + '.json', 'w') as f:
        json.dump(payment, f, indent=2)


