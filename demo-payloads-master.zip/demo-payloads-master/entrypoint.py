import sys
import os
sys.path.append("./")
import json
import csv
from order_builder import new_order, save_order, with_product, set_order_timestamp
from bol_builder import new_bol, save_bol, with_bol_product, set_bol_timestamp
from invoice_builder import new_invoice, with_invoice_product, save_invoice, set_invoice_timestamp
from invoice_bol_builder import new_invoice_bol, save_invoice_bol, set_invoice_bol_timestamp
from invoice_receipt_builder import new_invoice_receipt, save_invoice_receipt, set_invoice_receipt_timestamp
from receipt_builder import new_receipt, save_receipt, set_receipt_timestamp, with_receipt_product
from payment_builder import save_payment, set_payment_timestamp
from utils import logical_time, get_timestamp


def order_factory():
     with open("input/Cambio_data_sheet_order_no_header.csv") as fp:
        reader = csv.reader(fp, delimiter = ",")
        prev_line = None
        order = None
        for line in reader:
            if prev_line ==  None or prev_line[0] != line[0]:
                if (prev_line !=  None):
                    set_order_timestamp(get_timestamp())
                    save_order(order, prev_line)
                set_order_timestamp(get_timestamp())
                prev_line = line
                order = new_order(line)
            order = with_product(order, line)
        set_order_timestamp(get_timestamp())
        save_order(order, prev_line)
def bol_factory():
    with open("input/Cambio_data_sheet_bol_no_header.csv") as fp:
        reader = csv.reader(fp, delimiter = ",")
        prev_line = None
        bol = None
        for line in reader:
            if prev_line ==  None or prev_line[0] != line[0]:
                if (prev_line !=  None):
                    save_bol(bol, prev_line)
                set_bol_timestamp(get_timestamp())
                prev_line = line
                bol = new_bol(line)
            bol = with_bol_product(bol, line)
        save_bol(bol, prev_line)

def receipt_factory():
    with open("input/Cambio_data_sheet_receipt_no_header.csv") as fp:
        reader = csv.reader(fp, delimiter = ",")
        prev_line = None
        receipt = None
        for line in reader:
            if prev_line ==  None or prev_line[0] != line[0]:
                if (prev_line !=  None):
                    save_receipt(receipt, prev_line)
                set_receipt_timestamp(get_timestamp())
                prev_line = line
                receipt = new_receipt(line)
            receipt = with_receipt_product(receipt, line)
        save_receipt(receipt, prev_line)

def invoice_factory():
    with open("input/Cambio_invoice_no_header.csv") as fp:
        reader = csv.reader(fp, delimiter = ",")
        prev_line = None
        invoice = None
        for line in reader:
            if prev_line ==  None or prev_line[1] != line[1]:
                if (prev_line !=  None):
                    save_invoice(invoice, prev_line)
                set_invoice_timestamp(get_timestamp())
                prev_line = line
                invoice = new_invoice(line)
            invoice = with_invoice_product(invoice, line)
        save_invoice(invoice, prev_line)

def invoice_bol_factory():
    with open("input/Cambio_invoice_bol_no_header.csv") as fp:
        reader = csv.reader(fp, delimiter = ",")
        prev_line = None
        invoice = None
        for line in reader:
            if prev_line ==  None or prev_line[1] != line[1]:
                if (prev_line !=  None):
                    save_invoice_bol(invoice, prev_line)
                set_invoice_bol_timestamp(get_timestamp())
                prev_line = line
                invoice = new_invoice_bol(line)
            invoice = with_invoice_product(invoice, line)
        save_invoice_bol(invoice, prev_line)

def invoice_receipt_factory():
    with open("input/Cambio_invoice_receipt_no_header.csv") as fp:
        reader = csv.reader(fp, delimiter = ",")
        prev_line = None
        invoice = None
        for line in reader:
            if prev_line ==  None or prev_line[1] != line[1]:
                if (prev_line !=  None):
                    save_invoice_receipt(invoice, prev_line)
                set_invoice_receipt_timestamp(get_timestamp())
                prev_line = line
                invoice = new_invoice_receipt(line)
            invoice = with_invoice_product(invoice, line)
        save_invoice_receipt(invoice, prev_line)


def payment_factory():
    with open("input/Cambio_data_sheet_payment_no_header.csv") as fp:
        reader = csv.reader(fp, delimiter = ",")
        prev_line = None
        receipt = None
        payment_number = 1
        for line in reader:
            if prev_line !=  None and prev_line[0] == line[0]:
                payment_number += 1
                
            else :
                payment_number = 1
            set_payment_timestamp(get_timestamp())
            prev_line = line
            save_payment(line, payment_number)
            
            


if __name__ == "__main__":
    try :
        os.mkdir('output/')
    except OSError:
        print("Already Exists")
    order_factory()
    invoice_factory()
    bol_factory()
    invoice_bol_factory()
    receipt_factory()
    invoice_receipt_factory()
    payment_factory()



