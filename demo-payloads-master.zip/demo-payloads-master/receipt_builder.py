import sys
import os
sys.path.append("./")
from utils import org_name_to_id
import json
from datetime import datetime

timestamp = None

def set_receipt_timestamp(new_timestamp):
    global timestamp
    timestamp = new_timestamp

def new_receipt(line):
    receipt = {
    "action":"SET_RECEIPT",
    "purchase_order_number":line[2],
    "receipt":{
        "purchase_order_number":line[2],
        "timestamp":timestamp,
        "buyer":line[3],
        "supplier":line[4],
        "products":[],
        "date_order_received" : datetime.strptime(line[8], "%m/%d/%Y").strftime('%Y-%m-%d')
    },
    "timestamp":timestamp
    }

    return receipt

def with_receipt_product(receipt, line):
    product = {
           "product":line[5],
           "purchase_order_number":line[2],
           "quantity":int(line[6]),
           "quantity_unit_of_measure":line[7],
           "timestamp": timestamp
        }
    products = receipt["receipt"]["products"]
    products.append(product)
    receipt["receipt"]["products"] = products
    return receipt


def save_receipt(receipt, line):
    scenario = line[0].replace(" ", "_")

    with open('output/' + scenario + "/order" + '/set_receipt.json', 'w') as f:
        json.dump(receipt, f, indent=2)
    
    receipt['action'] = "SUBMIT_RECEIPT"

    with open('output/' + scenario + "/shipment" + '/submit_receipt.json', 'w') as f:
        json.dump(receipt, f, indent=2)


