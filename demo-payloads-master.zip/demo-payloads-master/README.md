# Cambio Demo Data
This script uses sepcifically formated [CSV files](/input) to generate Scabbared [paylods](/output) for cambio demo setup


### How to run
```
docker run -it --rm --name my-running-script -v "$PWD":/usr/src/datascript -w /usr/src/datascript python:3 python entrypoint.py
```
