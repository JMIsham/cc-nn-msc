from datetime import datetime, timedelta

org_name_to_id = {
    'Sysco' : 'syy', 
    'Cargill' : 'cgl',
    'Tyson' : 'tys',
    'Walmart' : 'wmt',
    'J.B. Hunt' : 'jbh'
}

logical_time = datetime.now()

def get_timestamp():
    global logical_time
    logical_time += timedelta(hours=1)
    return logical_time.astimezone().replace(microsecond=0).isoformat()