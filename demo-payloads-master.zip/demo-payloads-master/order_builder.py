import sys
import os
sys.path.append("./")
from utils import org_name_to_id
import json
from datetime import datetime

timestamp = None

def set_order_timestamp(new_timestamp):
    global timestamp
    timestamp = new_timestamp

def new_order(line):
    order = {
    "action" : "PROPOSE_PURCHASE_ORDER",
    "purchase_order_number": line[1],
    "purchase_order" : {
    "purchase_order_number": line[1],
    "buyer": org_name_to_id[line[2]],
    "supplier": org_name_to_id[line[3]],
    "timestamp": timestamp,
    "products": [],
    "date_order_expected":datetime.strptime(line[8], "%m/%d/%Y").strftime('%Y-%m-%d'),
    "date_order_close": datetime.strptime(line[9], "%m/%d/%Y").strftime('%Y-%m-%d'),
    "address_ship_from": {
        "street_address": line[10],
        "address_line_2": line[11],
        "city": line[12],
        "state": line[13],
        "zip_code": line[14]
    },
    "address_ship_to": {
        "street_address": line[15],
        "address_line_2": line[16],
        "city": line[17],
        "state": line[18],
        "zip_code": line[19]
    }
    },
    "timestamp": timestamp
    }
    return order

def with_product(order, line):
    product = {
           "product":line[4],
           "purchase_order_number":line[1],
           "quantity":int(line[5]),
           "quantity_unit_of_measure":line[6],
           "product_price":float((line[7].strip())[1:]),
           "timestamp": timestamp
        }
    products = order["purchase_order"]["products"]
    products.append(product)
    order["purchase_order"]["products"] = products
    return order

def accept_order(order, line):
    po_accept = {
    "action" : "ACCEPT_PURCHASE_ORDER",
    "purchase_order_number": line[1],
    "timestamp": timestamp
    }
    return po_accept

def save_order(order, line):
    scenario = line[0].replace(" ", "_")
    po_accept = accept_order(order, line)
    try:
        os.mkdir('output/' + scenario)
    except OSError:
        print ("Overwriting  %s files" % scenario)
    else:
        os.mkdir('output/' + scenario + "/order")
        os.mkdir('output/' + scenario + "/shipment")
    with open('output/' + scenario + "/order" + '/po.json', 'w') as f:
        json.dump(order, f, indent=2)
    
    with open('output/' + scenario + "/order" + '/po_accept.json', 'w') as f:
        json.dump(po_accept, f, indent=2)


