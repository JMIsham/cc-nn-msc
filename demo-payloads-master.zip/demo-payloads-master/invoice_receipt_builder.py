import sys
import os
sys.path.append("./")
from utils import org_name_to_id
import json

timestamp = None

def set_invoice_receipt_timestamp(new_timestamp):
    global timestamp
    timestamp = new_timestamp

def new_invoice_receipt(line):
    invoice = {
    "action":"UPDATE_INVOICE",
    "purchase_order_number":line[3],
    "invoice":{
        "invoice_number":line[2],
        "purchase_order_number":line[3],
        "timestamp":timestamp,
        "buyer":line[4],
        "supplier":line[5],
        "products":[]
    },
    "timestamp":timestamp
    }

    return invoice

def resolve_dispute(bol, line):
    resolve_dispute = {
    "action" : "RESOLVE_CLAIM",
    "purchase_order_number": line[3],
    "timestamp": timestamp
    }
    return resolve_dispute

def save_invoice_receipt(invoice, line):
    scenario = line[1].replace(" ", "_")
    resolve_dispute_json = resolve_dispute(invoice, line)

    with open('output/' + scenario + "/order" + '/update_invoice_receipt.json', 'w') as f:
        json.dump(invoice, f, indent=2)
    
    with open('output/' + scenario + "/shipment" + '/resolve_bol_gr.json', 'w') as f:
        json.dump(resolve_dispute_json, f, indent=2)
    



